</div> <!-- End Page Content -->

<footer class="footer py-4 mt-5">
    <div class="container-fluid px-4 text-center">
        <div class="small">
            &copy; 2025 <strong>Dalipuga Cleanup Management System</strong>
        </div>
        <div class="small text-white-50">
            Developed by <strong>Talongis Patogbong</strong>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
