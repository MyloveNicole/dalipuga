    <footer class="bg-dark text-white text-center py-4 mt-5">
        <div class="container">
            <p>&copy; <?= date('Y') ?> Dalipuga Cleanup Management System. All rights reserved.</p>
            <p class="small">For support, contact your administrator.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/jadiz/public/assets/js/main.js"></script>
</body>
</html>
